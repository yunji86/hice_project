package com.greedy.coffee.common;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {

}
