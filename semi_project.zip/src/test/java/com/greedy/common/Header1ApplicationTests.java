package com.greedy.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Header1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
